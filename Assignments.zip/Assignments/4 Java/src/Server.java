/* D.S Kapnias u18108467 */
/* L.M Burgess u18015001 */

import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.StringTokenizer;
import java.util.Base64;
import java.nio.file.Files;


/*
Schema: phonebook
Table: pages
fields: phone_number(pk), name
 */

public class Server {
    public static Connection conn = null;
    public static void main(String[] args) throws SQLException {
        ServerSocket Server = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/phonebook?user=root&password=L19m2992@root");
            Server = new ServerSocket(5000);
            while (true) {
                new Client(Server.accept()).start();
            }

        } catch (IOException | SQLException e) {
            e.printStackTrace();
        } finally {
            conn.close();
        }
    }

    static class Client extends Thread {
        StringTokenizer breaker = null;
        Socket socket;
        BufferedReader  input= null;
        OutputStream output= null;
        String req[];


        public Client(Socket user) {
            socket = user;
            try {
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                output = socket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void run() {
            super.run();
            try {
                String line = null;
                line = input.readLine();
                if(line != null) {
                    System.out.println(line);
                    req = parseRequest(line);
                    if(req[0].equals("GET")) {
                        if(req[1].equals("/")) {
                            printHTML("\r\n","","","","", output, null);
                        }
                    } else if(req[0].equals("POST") && !req[1].equals("/image")) {
                        Statement stmt = null;
                        ResultSet rs = null;
                        String content = returnContent(input);
                        String r1="",r2="",r3="",r4="",r5="";
                        if(req[1].equals("/find")) {
                            if(content.contains("find=")) {
                                String name = content.substring(content.indexOf("=")+1);
                                print(name);
                                name = name.substring(0, name.indexOf("+"))+" "+name.substring(name.indexOf("+")+1);
                                print(name);
                                print("find");
                                stmt = conn.createStatement();
                                rs = stmt.executeQuery("SELECT * FROM page WHERE name like '%"+name+"%'");
                                while(rs.next()) {
                                    r2 = r2 + rs.getString(1)+" "+ rs.getString(2) +"<br>";
                                }
                            }
                        } else if(req[1].equals("/add")) {
                            print(content);
                            if(content.contains("userName=") && content.contains("userNumber=")) {
                                String name = content.substring(content.indexOf("=")+1, content.indexOf('&'));
                                name = name.substring(0, name.indexOf("+"))+" "+name.substring(name.indexOf("+")+1);
                                String number = content.substring(content.indexOf('&')+1);
                                number = number.substring(number.indexOf("=")+1);

                                stmt = conn.createStatement();
                                rs = stmt.executeQuery("SELECT * FROM page WHERE phone_number = '"+number+"'");
                                if(rs.next()!=false)
                                    r3 = "Already Exists";
                                else {
                                    stmt.close();
                                    stmt = conn.createStatement();
                                    stmt.executeUpdate("INSERT INTO page VALUES ('" + number + "','" + name + "')");
                                    r3 = number + " " + name + "\r\n";
                                }
                            }
                        } else if(req[1].equals("/update")) {
                            if(content.contains("uName=") && content.contains("uNum=")) {
                                String name = content.substring(content.indexOf("=")+1, content.indexOf('&'));
                                name = name.substring(0, name.indexOf("+"))+" "+name.substring(name.indexOf("+")+1);
                                String number = content.substring(content.indexOf('&')+1);
                                number = number.substring(number.indexOf("=")+1);

                                stmt = conn.createStatement();
                                rs = stmt.executeQuery("SELECT * FROM page WHERE name like '%"+name+"%'");
                                if(rs.next()==false)
                                    r4 = "Not found";
                                else {
                                    stmt.close();
                                    stmt = conn.createStatement();
                                    stmt.executeUpdate("UPDATE page SET phone_number='"+number+"' WHERE name='"+name+"'");
                                    r4 = number+" "+name+"\r\n";
                                }
                            }
                        } else if(req[1].equals("/remove")) {
                            if(content.contains("Name=") && content.contains("Number=")) {
                                String name = content.substring(content.indexOf("=")+1, content.indexOf('&'));
                                name = name.substring(0, name.indexOf("+"))+" "+name.substring(name.indexOf("+")+1);
                                String number = content.substring(content.indexOf('&')+1);
                                number = number.substring(number.indexOf("=")+1);

                                stmt = conn.createStatement();
                                rs = stmt.executeQuery("SELECT * FROM page WHERE phone_number = '"+number+"'");
                                if(rs.next()==false)
                                    r5 = "Not found";
                                else {
                                    stmt = conn.createStatement();
                                    stmt.executeUpdate("DELETE FROM page WHERE name='" + name + "'");
                                    r5 = "Deleted";
                                }
                            }
                        } else if(req[1].equals("/show")) {
                            print("show");
                            stmt = conn.createStatement();
                            rs = stmt.executeQuery("SELECT * FROM page");
                            while(rs.next()) {
                                r1 += rs.getString(1)+" "+ rs.getString(2) + "<br>";
                            }
                        }
                        printHTML(r1,r2,r3,r4,r5, output, null);
                    } else if(req[0].equals("POST") && req[1].equals("/image")) {
                        //print(req[1]);
                        line = input.readLine();
                        //print("POST\n");
                        while(!line.contains("Content-Length:")) {
                            line = input.readLine();
                            while (line == null) {
                            }
                        }
                        print(line);
                        int length = Integer.parseInt(line.substring(line.indexOf(":")+1,line.length()).trim());
                        if(length==0)
                            badHeaders("","");
                        else {
                            //print("Parse Headers");
                            while (line.length() > 0) {
                                //print(line);
                                line = input.readLine();
                            }
                            line = "";
                            String hold="";
                            int counter=0;
                            while (counter<3) {
                                hold= input.readLine();

                                if(hold.contains("WebKitFormBoundary")) {
                                    print("BOUNDARY");
                                    counter++;

                                    /* Expect Name of user */
                                    if(counter==1) {
                                        hold = input.readLine();
                                        String field = hold.substring(hold.indexOf('"')+1, hold.length()-1);
                                        print(field);
                                        if(field!="upName") {
                                            //fail
                                        }
                                        input.readLine();
                                        hold = input.readLine();
                                        print("User: "+hold);
                                        /* User exists... */


                                    }
                                    /* End of user boundary / beginning of image boundary */
                                    else if(counter==2) {
                                        input.readLine();
                                        input.readLine();
                                        input.readLine();
                                        /* This is the png line i think */
                                        input.readLine();
                                        hold="";
                                        line="";
                                        /* line holds the whole picture */
                                        while(!hold.contains("WebKitFormBoundary")) {
                                            line += hold;
                                            hold = input.readLine();
                                            print("Line: "+hold);
                                        }
                                        print(line);
                                        /* write to db / file */
                                        try {
                                            writeToFile(line);
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }

                                        counter++;

                                        /******************************************************************/
                                        File f = new File("image.png");
                                        /******************************************************************/

                                        /* end of request */
                                        print(String.valueOf(length));
                                        printHTML("r1", "r2", "r3", "r4", "r5", output, f);
                                    }
                                }
                            }
                            printHTML("r1","r2","r3","r4","r5", output, null);
                        }
                    }
                }
            } catch (IOException | SQLException e) {
                e.printStackTrace();
            }
        }

        private void writeToFile(String fileChars) throws IOException {
            File fileObj = new File("upload.png");
            fileObj.delete();
            fileObj.createNewFile();
            FileWriter writer = new FileWriter("upload.png");
            writer.write(fileChars);
            writer.close();
        }

        private String returnContent(BufferedReader in) throws IOException {
            String line;
            //print(req[1]);
            line = in.readLine();
            //print("POST\n");
            while(!line.contains("Content-Length:")) {
                line = in.readLine();
                while (line == null) {
                }
            }
            int length = Integer.parseInt(line.substring(line.indexOf(":")+1,line.length()).trim());

            if(length==0)
                badHeaders("","");
            else {
                //print("Parse Headers");
                while (line.length() > 0) {
                    //print(line);
                    line = in.readLine();
                }

                line = "";
                while (length > 0) {
                    length -= 1;
                    line += (char) in.read();
                }

            }
            return line;
        }

        private void badHeaders(String s, String s1) {
            String status_line = "HTTP/1.1 400 Bad Request \r\n";
            String Header = "Content-Type: text/html\r\nContent-Length: 0\r\n";
            String Empty = "\r\n";
        }

        private String[] parseRequest(String line) throws Error {
            String ret[] = new String[3];
            breaker = new StringTokenizer(line);
            for (int i = 0; i < 3; i++) {
                if(breaker.hasMoreTokens()) {
                    ret[i] = breaker.nextToken();
                    //print(ret[i]);
                } else {
                    throw new Error("Request faulty");
                }
            }
            return ret;
        }

    }

    public static void printHTML(String r1, String r2, String r3, String r4, String r5, OutputStream output, File f) throws IOException {
        File fIn = new File("image.png");
        /* gen resp */
        String status_line = "HTTP/1.1 200 OK \r\n";
        String BodyStart = "\r\n";
        String HTML = "<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <title>Title</title>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <div style=\"outline-style: auto; padding: 20px\">\n" +
                "    <h1>Show All</h1>\n" +
                "    <form method=\"post\" action=\"/show\">\n" +
                "        <button type=\"submit\">Show All</button>\n" +
                "    </form>\n" +
                "    <div>Result:<br><p>\n" +
                "\n" +
                "    "+r1+"</p></div>\n" +
                "    </div>\n" +
                "    <div style=\"outline-style: auto; padding: 20px\">\n" +
                "        <h1>Find Friend</h1>\n" +
                "        <form method=\"post\" action=\"/find\">\n" +
                "            <label for=\"find\">Friend Name</label>\n" +
                "            <input id=\"find\" name=\'find\' type=\"text\">\n" +
                "            <button type=\"submit\">Show All</button>\n" +
                "        </form>\n" +
                "        <div>Result:<br><p>\n" +
                "\n" +
                "        "+r2+"</p></div>\n" +
                "    </div>\n" +
                "    <div style=\"outline-style: auto; padding: 20px\">\n" +
                "        <h1>Add Friend</h1>\n" +
                "        <form method=\"post\" action=\"/add\">\n" +
                "            <label for=\"userName\">Friend Name</label>\n" +
                "            <input id=\"userName\" name=\'userName\' type=\"text\">\n" +
                "            <label for=\"userNumber\">Friend Phone Number</label>\n" +
                "            <input id=\"userNumber\" name=\'userNumber\' type=\"text\">\n" +
                "            <button type=\"submit\">Add</button>\n" +
                "        </form>\n" +
                "        <div>Result:<br><p>\n" +
                "\n" +
                "        "+r3+"</p></div>\n" +
                "    </div>\n" +
                "    <div style=\"outline-style: auto; padding: 20px\">\n" +
                "        <h1>Update Friend</h1>\n" +
                "        <form method=\"post\" action=\"/update\">\n" +
                "            <label for=\"uName\">Friend Name</label>\n" +
                "            <input id=\"uName\" name=\'uName\' type=\"text\">\n" +
                "            <label for=\"uNum\">New Number</label>\n" +
                "            <input id=\"uNum\" name=\'uNum\' type=\"text\">\n" +
                "            <button type=\"submit\">Change</button>\n" +
                "        </form>\n" +
                "        <div>Result:<br><p>\n" +
                "\n" +
                "        "+r4+"</p></div>\n" +
                "    </div>\n" +
                "    <div style=\"outline-style: auto; padding: 20px\">\n" +
                "        <h1>Remove Friend</h1>\n" +
                "        <form method=\"post\" action=\"/remove\">\n" +
                "            <label for=\"Name\">Friend Name</label>\n" +
                "            <input id=\"Name\" name=\'Name\' type=\"text\">\n" +
                "            <label for=\"Number\">Friend Phone Number</label>\n" +
                "            <input id=\"Number\" name=\'Number\' type=\"text\">\n" +
                "            <button type=\"submit\">Delete</button>\n" +
                "        </form>\n" +
                "        <div>Result:<br><p>\n" +
                "\n" +
                "        "+r5+"</p></div>\n" +
                "    </div>\n" +
                "<div style=\"outline-style: auto; padding: 20px\">\n" +
                "    <h1>Image</h1>\n" +
                "<img src=\"data:image/png;base64," +
                Base64.getEncoder().encodeToString(Files.readAllBytes(fIn.toPath())) +
                "\" alt=\"Base64 encoded image\" width=\"150\" height=\"150\"/>" +
                "</div>" +
                "</body>\n" +
                "</html>";

        String Header = "Content-Type: text/html\r\nContent-Length: ";
        Header += String.valueOf(HTML.getBytes(StandardCharsets.UTF_8).length) +"\r\n";
        /* Send http response */
        output.write(status_line.getBytes(StandardCharsets.UTF_8));
        output.write(Header.getBytes(StandardCharsets.UTF_8));
        output.write(BodyStart.getBytes(StandardCharsets.UTF_8));
        output.write(HTML.getBytes(StandardCharsets.UTF_8));

        output.flush();
    }



    public static void print(String line) {
        System.out.println(line);
    }
}