import datetime
import socket
import keyboard

def genMail(DATA):
    s = socket.socket()
    s.connect(("196.248.34.207", 25))
    # 220 mail.prac.com ESMTP Postfix (Ubuntu)
    print(s.recv(512).decode('UTF-8'))
    s.send(b"HELO liam\r\n")
    # 250 mail.prac.com
    print(s.recv(512).decode('UTF-8'))
    s.send(b"MAIL FROM:alert@prac.com\r\n")
    # 250 2.1.0 Ok
    print(s.recv(512).decode('UTF-8'))
    #s.send(b"RCPT TO:liam@prac.com\r\n")
    s.send(b"RCPT TO:group\r\n")
    # 250 2.1.5 Ok
    print(s.recv(512).decode('UTF-8'))
    s.send(b"DATA \r\n")
    print(s.recv(512).decode('UTF-8'))
    x = datetime.datetime.now()
    inp = "Date: "+x.strftime("%d %b %Y")+"\r\n"
    inp += "From: alert@gmail.com\r\n"
    inp += "To: group@prac.com\r\n"
    inp += "Subject: ALERT\r\n"
    if DATA == "SPECIAL_ALERT":
        inp += "SPECIAL_ALERT: Owner notified"
    else:
        inp += "ALERT: " + DATA
    inp += "\r\n\r\n"
    inp += DATA + " alarm was triggered"
    s.send(inp.encode("UTF-8"))
    s.send(b"\r\n")
    s.send(b".")
    s.send(b"\r\n")
    print(s.recv(512).decode('UTF-8'))
    s.send(b"QUIT\r\n")
    s.close()

while True:
    if keyboard.read_key() == 'w':
        genMail("FRONT_DOOR")
    elif keyboard.read_key() == 'a':
        genMail("WINDOW_BEDROOM")
    elif keyboard.read_key() == 's':
        genMail("WINDOW_KITCHEN")
    elif keyboard.read_key() == 'd':
        genMail("BACK_DOOR")
    elif keyboard.read_key() == 'i':
        genMail("SPECIAL_ALERT")
    elif keyboard.read_key() == 'e':
        break
