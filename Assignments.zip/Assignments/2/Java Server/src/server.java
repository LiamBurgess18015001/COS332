/* D.S Kapnias u18108467 */
/* L.M Burgess u18015001 */

/*
    change
    add
    show
    find
    delete
 */

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class server {
    private static Lock lock;
    public static void main(String[] args){
        try{
            lock = new ReentrantLock();
            database DB = new database();
            ServerSocket socket = new ServerSocket(5000);
            print("Socket build");
            print("Open for connections");
                while (true) {
                    Socket connect = socket.accept();
                    new client_connection(connect, DB).start();
                }

        } catch(Exception e) {
            System.out.print(e);
        }
    }

    private static void print(String line) {
        System.out.println(line);
    }

    static class client_connection extends Thread {
        private Socket socket;
        BufferedReader input;
        PrintStream output;
        static int num=0;
        database db;

        client_connection(Socket socket, database db) {
            this.socket = socket;
            this.db = db;
        }

        /******************************************************************/

        private final byte[] hourglass = {
                0x2B, 0x3D, 0x3D, 0x3D, 0x3D, 0x2B, 0x0A, 0x7C, 0x28, 0x3A, 0x3A,
                0x29, 0x7C, 0x0A, 0x7C, 0x20, 0x29, 0x28, 0x20, 0x7C, 0x0A, 0x7C,
                0x28, 0x2E, 0x2E, 0x29, 0x7C, 0x0A, 0x2B, 0x3D, 0x3D, 0x3D, 0x3D,
                0x2B
        };
        private final byte[] hourglass_rev = {
                0x2B, 0x3D, 0x3D, 0x3D, 0x3D, 0x2B, 0x0A, 0x7C, 0x28, 0x2E, 0x2E,
                0x29, 0x7C, 0x0A, 0x7C, 0x20, 0x29, 0x28, 0x20, 0x7C, 0x0A, 0x7C,
                0x28, 0x3A, 0x3A, 0x29, 0x7C, 0x0A, 0x2B, 0x3D, 0x3D, 0x3D, 0x3D,
                0x2B
        };
        private final byte[] prog_name = {
                0x5F, 0x5F, 0x5F, 0x5F, 0x5F, 0x5F, 0x20, 0x20, 0x20, 0x20, 0x20,
                0x20, 0x5F, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
                0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x5F,
                0x20, 0x5F, 0x5F, 0x5F, 0x5F, 0x5F, 0x5F, 0x20, 0x20, 0x20, 0x20,
                0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
                0x20, 0x5F, 0x20, 0x20, 0x20, 0x20, 0x0A, 0x7C, 0x20, 0x20, 0x5F,
                0x5F, 0x5F, 0x7C, 0x20, 0x20, 0x20, 0x20, 0x28, 0x5F, 0x29, 0x20,
                0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
                0x20, 0x20, 0x20, 0x20, 0x20, 0x7C, 0x20, 0x7C, 0x7C, 0x20, 0x5F,
                0x5F, 0x5F, 0x20, 0x5C, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
                0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x7C, 0x20, 0x7C, 0x20,
                0x20, 0x20, 0x0A, 0x7C, 0x20, 0x7C, 0x5F, 0x20, 0x20, 0x5F, 0x20,
                0x5F, 0x5F, 0x20, 0x20, 0x5F, 0x20, 0x20, 0x20, 0x5F, 0x5F, 0x5F,
                0x20, 0x20, 0x5F, 0x20, 0x5F, 0x5F, 0x20, 0x20, 0x20, 0x20, 0x5F,
                0x5F, 0x7C, 0x20, 0x7C, 0x7C, 0x20, 0x7C, 0x5F, 0x2F, 0x20, 0x2F,
                0x20, 0x20, 0x5F, 0x5F, 0x5F, 0x20, 0x20, 0x20, 0x20, 0x5F, 0x5F,
                0x5F, 0x20, 0x20, 0x7C, 0x20, 0x7C, 0x20, 0x5F, 0x5F, 0x0A, 0x7C,
                0x20, 0x20, 0x5F, 0x7C, 0x7C, 0x20, 0x27, 0x5F, 0x5F, 0x7C, 0x7C,
                0x20, 0x7C, 0x20, 0x2F, 0x20, 0x5F, 0x20, 0x5C, 0x7C, 0x20, 0x27,
                0x5F, 0x20, 0x5C, 0x20, 0x20, 0x2F, 0x20, 0x5F, 0x60, 0x20, 0x7C,
                0x7C, 0x20, 0x5F, 0x5F, 0x5F, 0x20, 0x5C, 0x20, 0x2F, 0x20, 0x5F,
                0x20, 0x5C, 0x20, 0x20, 0x2F, 0x20, 0x5F, 0x20, 0x5C, 0x20, 0x7C,
                0x20, 0x7C, 0x2F, 0x20, 0x2F, 0x0A, 0x7C, 0x20, 0x7C, 0x20, 0x20,
                0x7C, 0x20, 0x7C, 0x20, 0x20, 0x20, 0x7C, 0x20, 0x7C, 0x7C, 0x20,
                0x20, 0x5F, 0x5F, 0x2F, 0x7C, 0x20, 0x7C, 0x20, 0x7C, 0x20, 0x7C,
                0x7C, 0x20, 0x28, 0x5F, 0x7C, 0x20, 0x7C, 0x7C, 0x20, 0x7C, 0x5F,
                0x2F, 0x20, 0x2F, 0x7C, 0x20, 0x28, 0x5F, 0x29, 0x20, 0x7C, 0x7C,
                0x20, 0x28, 0x5F, 0x29, 0x20, 0x7C, 0x7C, 0x20, 0x20, 0x20, 0x3C,
                0x20, 0x0A, 0x5C, 0x5F, 0x7C, 0x20, 0x20, 0x7C, 0x5F, 0x7C, 0x20,
                0x20, 0x20, 0x7C, 0x5F, 0x7C, 0x20, 0x5C, 0x5F, 0x5F, 0x5F, 0x7C,
                0x7C, 0x5F, 0x7C, 0x20, 0x7C, 0x5F, 0x7C, 0x20, 0x5C, 0x5F, 0x5F,
                0x2C, 0x5F, 0x7C, 0x5C, 0x5F, 0x5F, 0x5F, 0x5F, 0x2F, 0x20, 0x20,
                0x5C, 0x5F, 0x5F, 0x5F, 0x2F, 0x20, 0x20, 0x5C, 0x5F, 0x5F, 0x5F,
                0x2F, 0x20, 0x7C, 0x5F, 0x7C, 0x5C, 0x5F, 0x5C
        };

        public void clear(PrintStream out, int row, int col) {
            out.println(String.format("\u001B[%d;%dH\u001B[0J", row, col));
        }

        public void load_splash(PrintStream out) {
            try {
                out.println("\u001B[2J");
                out.print("\u001B[H");
                out.println("Loading Database...");

                out.println("\u001B[?25l\u001B[2;0H\u001B[1;36m");
                for (int i = 0; i < 4; i++) {
                    out.println(new String(hourglass));
                    Thread.sleep(500);
                    out.println("\u001B[2;0H\u001B[0J");
                    out.println(new String(hourglass_rev));
                    Thread.sleep(500);
                    out.println("\u001B[2;0H\u001B[0J");
                }
            } catch (Exception e) {}

            out.println("\u001B[1;32mDatabase successfully loaded");
            out.println("\u001B[?25h\u001B[0m");
        }

        public void load_name(PrintStream out) {
            out.println("\u001B[H\u001B[1;35m\u001B[0J");
            out.println(new String(prog_name));
            out.println("\u001B[0m");
        }

        /******************************************************************/
        public void run() {
            try {

                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                output = new PrintStream(socket.getOutputStream());

                load_splash(output);
                load_name(output);

                output.print(">Connected to server\r\n");
                output.print(">Connection number "+(num++)+"\r\n");

                String received = "";
                String user = "Client "+num + ">";
                while((received = input.readLine())!= null && !received.equals(":quit")) {
                    output.print(user+received+"\r\n");
                    if(received.equals("add")) {
                        output.print("Person Name and Surname:\r\n");
                        String name = input.readLine();
                        if(name.equals(":quit"))
                            break;
                        else if(name.equals("cancel")) {
                            continue;
                        }
                        output.print("Person Telephone:\r\n");
                        String telephone = input.readLine();
                        if(telephone.equals(":quit"))
                            break;
                        else if(telephone.equals("cancel"))
                            continue;
                        if(addTelephone(name, telephone)) {
                            output.print("Person added\r\n");
                        }
                        else
                            output.print("Add failed\r\n");
                    } else if(received.equals("show")) {
                        output.print(showTelephone()+"\r\n");
                    } else if(received.equals("remove")) {
                        output.print("Person Name and Surname:\r\n");
                        String name = input.readLine();
                        if(name.equals(":quit"))
                            break;
                        if(name.equals("cancel"))
                            continue;
                        if(deleteTelephone(name))
                            output.print("Person deleted\r\n");
                        else
                            output.print("Delete failed: please check the name provided\r\n");
                    } else if (received.equals("change")){
                        output.print("Person Name and Surname:\r\n");
                        String name = input.readLine();
                        if(name.equals(":quit"))
                            break;
                        if(name.equals("cancel"))
                            continue;
                        output.print("Person New Telephone:\r\n");
                        String telephone = input.readLine();
                        if(telephone.equals(":quit"))
                            break;
                        if(telephone.equals("cancel"))
                            continue;
                        if(updateTelephone(name, telephone))
                            output.print("Person updated\r\n");
                        else
                            output.print("Update failed\r\n");
                    } else if (received.equals("find")) {
                        output.print("Person Name and Surname:\r\n");
                        String name = input.readLine();
                        if(name.equals(":quit"))
                            break;
                        if(name.equals("cancel"))
                            continue;
                        output.print(find(name));
                    }
                }

                System.out.print("Closing");
                input.close();
                output.close();
                socket.close();

            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                db.commit();
            }
        }

        private boolean addTelephone(String name, String telephone) {
            lock.lock();
            String line[] = {name , telephone};
            try {
                db.db.add(line);
            } finally {
                lock.unlock();
            }
            return true;
        }

        private boolean deleteTelephone(String name) {
            lock.lock();
            try {
                db.db.trimToSize();
                for (int i = 0; i < db.db.capacity(); i++) {
                    if(db.db.get(i)[0].equals(name)) {
                        db.db.remove(i);
                        return true;
                    }
                }
            } finally {
                lock.unlock();
            }
            return false;
        }

        private String showTelephone() {
            String sline = "";
            lock.lock();
            try {
                db.db.trimToSize();
                for (int i = 0; i < db.db.capacity(); i++) {
                    sline+= (db.db.get(i)[0]+" : "+db.db.get(i)[1]+"\r\n");
                }
            } finally {
                lock.unlock();
            }
            return sline;
        }

        private boolean updateTelephone(String name, String telephone) {
            lock.lock();
            try {
                db.db.trimToSize();
                for (int i = 0; i < db.db.capacity(); i++) {
                    if(db.db.get(i)[0].equals(name)) {
                        db.db.get(i)[1] = telephone;
                        return true;
                    }
                }
            } finally {
                lock.unlock();
            }
            return false;
        }

        private String find(String name) {
            lock.lock();
            try {
                db.db.trimToSize();
                for (int i = 0; i < db.db.capacity(); i++) {
                    if (db.db.get(i)[0].equals(name)) {
                        return name + ", " + db.db.get(i)[1]+"\r\n";
                    }
                }
            } finally {
                lock.unlock();
            }
            return "NOT FOUND\r\n";
        }
    }

    private static class database {
        public static Vector<String[]> db = new Vector<String[]>();
        private Scanner reader;

        database() {
            initDB();
        }
        private void initDB() {
            File file = new File("phonebook.txt");
            try {
                reader = new Scanner(file);
            } catch (FileNotFoundException e) {
                throw new Error("Phonebook file missing");
            }
            while(reader.hasNext()) {
                db.add(reader.nextLine().split(","));
            }
            reader.close();
        }
        public void commit() {
            try {
                FileWriter write = new FileWriter("phonebook.txt");
                db.trimToSize();
                String line = "";
                for (int i = 0; i < db.capacity(); i++) {
                    line = db.get(i)[0]+","+db.get(i)[1]+"\r\n";
                    //System.out.print(line);
                    write.write(line);
                }
                write.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
