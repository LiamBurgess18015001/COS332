const http = require('http');
const express = require("express");
const fs = require("fs");
const bodyParser = require('body-parser')
const app = express();
const port = 5000;
let file;
const server = http.createServer(app);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended:true
}));

app.get('/', (req, res) => {
    printHTML(res);
    res.end();
});

app.post('/show', (req,res)=> {
    let r1="";
    for (let i = 0; i < file.length; i++) {
        r1 += file[i]["name"]+", "+file[i]["number"]+"<br>";
    }
    printHTML(res, r1);
    res.end();
});

app.post('/find', (req,res)=> {
    let r2 = "Friend not found";
    for (let i = 0; i < file.length; i++) {
        if(file[i]['name']==req.body['find']) {
            r2 = "Friend: <br>" + file[i]["name"] + ", " + file[i]["number"] + "<br>";
            break;
        }
    }
    printHTML(res,"",r2);
    res.end();
});

app.post('/add', (req,res)=> {
    let r3 = "Friend added";
    if(req.body['userNumber'].trim()=="")
        r3 = "Phone Number missing";
    else if(req.body['userName'].trim()=="")
        r3 = "Name missing";
    else {
        let found =false;
        for (let i = 0; i < file.length; i++) {
            if(req.body['userName']==file[i]['name'])
                found = true;
        }
        if(found)
            r3 = "Friend already added"
        else
            file.push({name:req.body['userName'], number:req.body['userNumber']});
    }
    printHTML(res,"","",r3);
    res.end();
});

app.post('/update', (req,res)=> {
    let r4 = "Updated friend's number";
    if(req.body['uNum'].trim()=="")
        r4 = "Phone Number missing";
    else if(req.body['uName'].trim()=="")
        r4 = "Name missing";
    else {
        let found = false;
        for (let i = 0; i < file.length; i++) {
            if (req.body['uName'] == file[i]['name']) {
                found = true;
                file[i]['number']=req.body['uNum'];
                break;
            }
        }
        if(!found)
            r4 = "Friend not found";
    }
    printHTML(res,"","","", r4);
    res.end();
});

app.post('/remove', (req,res)=> {
    let r5 = "Deleted friend";
    if(req.body['Number'].trim()=="" && req.body['Name'].trim()=="")
        r5 = "One of the two fields is required";
    else {
        let found = false;
        for (let i = 0; i < file.length; i++) {
            if (req.body['Name'] == file[i]['name'] || req.body['Number'] == file[i]['number']) {
                found = true;
                file.splice(i,1);
                break;
            }
        }
        if(!found)
            r5 = "Friend not found";
    }
    printHTML(res,"","","", "", r5);
    res.end();
});

app.post('/image', (req,res)=> {
    let data = "";
    req.on('data', chunk => {
        data += chunk;
    });
    req.on('end', () => {
       console.log(data);
    });
    res.redirect('/');
});

server.listen(port, ()=> {
    readTXT();
    console.log('Server started on Port: '+ port);
});

function readTXT() {
    fs.readFile('phonebook.json', "utf8",(err, data) => {
        if (err) {
            console.error(err)
            return
        }
        file = JSON.parse(data);
    });
}

function printHTML(res, r1="", r2="", r3="", r4="", r5="") {
    res.send("<!DOCTYPE html>\n" +
        "<html lang=\"en\">\n" +
        "<head>\n" +
        "    <meta charset=\"UTF-8\">\n" +
        "    <title>Title</title>\n" +
        "</head>\n" +
        "<body>\n" +
        "    <div style=\"outline-style: auto; padding: 20px\">\n" +
        "    <h1>Show All</h1>\n" +
        "    <form method=\"post\" action=\"/show\">\n" +
        "        <button type=\"submit\">Show All</button>\n" +
        "    </form>\n" +
        "    <div>Result:<br><p>\n" +
        "\n" +
        "    "+r1+"</p></div>\n" +
        "    </div>\n" +
        "    <div style=\"outline-style: auto; padding: 20px\">\n" +
        "        <h1>Find Friend</h1>\n" +
        "        <form method=\"post\" action=\"/find\">\n" +
        "            <label for=\"find\">Friend Name</label>\n" +
        "            <input id=\"find\" name=\'find\' type=\"text\">\n" +
        "            <button type=\"submit\">Show All</button>\n" +
        "        </form>\n" +
        "        <div>Result:<br><p>\n" +
        "\n" +
        "        "+r2+"</p></div>\n" +
        "    </div>\n" +
        "    <div style=\"outline-style: auto; padding: 20px\">\n" +
        "        <h1>Add Friend</h1>\n" +
        "        <form method=\"post\" action=\"/add\">\n" +
        "            <label for=\"userName\">Friend Name</label>\n" +
        "            <input id=\"userName\" name=\'userName\' type=\"text\">\n" +
        "            <label for=\"userNumber\">Friend Phone Number</label>\n" +
        "            <input id=\"userNumber\" name=\'userNumber\' type=\"text\">\n" +
        "            <button type=\"submit\">Add</button>\n" +
        "        </form>\n" +
        "        <div>Result:<br><p>\n" +
        "\n" +
        "        "+r3+"</p></div>\n" +
        "    </div>\n" +
        "    <div style=\"outline-style: auto; padding: 20px\">\n" +
        "        <h1>Update Friend</h1>\n" +
        "        <form method=\"post\" action=\"/update\">\n" +
        "            <label for=\"uName\">Friend Name</label>\n" +
        "            <input id=\"uName\" name=\'uName\' type=\"text\">\n" +
        "            <label for=\"uNum\">New Number</label>\n" +
        "            <input id=\"uNum\" name=\'uNum\' type=\"text\">\n" +
        "            <button type=\"submit\">Change</button>\n" +
        "        </form>\n" +
        "        <div>Result:<br><p>\n" +
        "\n" +
        "        "+r4+"</p></div>\n" +
        "    </div>\n" +
        "    <div style=\"outline-style: auto; padding: 20px\">\n" +
        "        <h1>Remove Friend</h1>\n" +
        "        <form method=\"post\" action=\"/remove\">\n" +
        "            <label for=\"Name\">Friend Name</label>\n" +
        "            <input id=\"Name\" name=\'Name\' type=\"text\">\n" +
        "            <label for=\"Number\">Friend Phone Number</label>\n" +
        "            <input id=\"Number\" name=\'Number\' type=\"text\">\n" +
        "            <button type=\"submit\">Delete</button>\n" +
        "        </form>\n" +
        "        <div>Result:<br><p>\n" +
        "\n" +
        "        "+r5+"</p></div>\n" +
        "    </div>\n" +
        "<div style=\"outline-style: auto; padding: 20px\">\n" +
        "    <h1>Add Image</h1>\n" +
        "    <form method=\"post\" action=\"/image\" enctype=\'multipart/form-data\'>\n" +
        "        <label for=\"upName\">Friend Name</label>\n" +
        "        <input id=\"upName\" name=\"upName\" type=\"text\">\n" +
        "        <label for=\"upload\">Submit image</label>\n" +
        "        <input type=\"file\" id=\"upload\" name=\"upload\">\n" +
        "        <button type=\"submit\">Upload</button>\n" +
        "    </form>\n" +
        "</div>"+
        "</body>\n" +
        "</html>");
}