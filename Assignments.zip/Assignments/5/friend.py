import binascii
import socket

def BERString(sline):
    line = binascii.hexlify(sline)
    length = binascii.hexlify(len(sline).to_bytes(1, 'big'))
    #length = len(sline).to_bytes(1, 'big')
    tag = '04'
    return tag, length, line


def addHex(v1,v2):
    return hex(int(v1, 16) + int(v2, 16))


def uidName(sline:str):
    return sline[0]+sline[sline.find(" ")+1:len(sline)]


Host ='192.168.0.118'
Port = 389

#query = '3030020102642b040e64633d707261632c64633d636f6d3019300f040b6f626a656374436c61737331003006040264633100'
#old_query = '3053020102634e040e64633d707261632c64633d636f6d0a01020a0100020203e802011e010100a024a315040b6f626a656374436c6173730406706572736f6ea30b040375696404046a646f65300604012a04012b'

while True:

    find = input('Name: ')
    if find == 'quit':
        break

    if not(" " in find):
        continue

    big_total = b'29'
    search_total = b'24'
    and_total = b'0'
    eq_total = b'7'

    # Build uid query
    tag, length, line = BERString(uidName(find).encode('UTF-8'))

    # add length to eq
    eq_total = addHex(eq_total, length)
    print(eq_total)

    # add upwards to top
    and_total = addHex(and_total, eq_total)
    print(and_total)

    search_total = addHex(search_total, and_total)
    print(search_total)

    big_total = addHex(big_total, and_total)
    print(big_total)

    if len(eq_total) < 4:
        eq_total = '0x0'+eq_total[2:]

    # build query
    query = '30'+big_total[2:]
    query = query + '02010263'+search_total[2:]
    query = query + '0421636e3d667269656e642c6f753d67726f75702c64633d707261632c64633d636f6d'
    query = query + '0a01020a0100020203e802011e010100'
    #query = query + 'a0'+and_total[2:]
    #query = query + 'a315040b6f626a656374436c6173730406706572736f6e'
    #query = query + 'a3080402636e0406667269656e64'
    query = query + 'a3'+eq_total[2:]+'0403756964'

    print(line)
    print(bytes.decode(line))
    query = query + tag + bytes.decode(length) + bytes.decode(line)

    query = query + '300604012a04012b'

    print(query)

    s = socket.socket()
    s.connect((Host, Port))
    print('Connected')
    s.send(bytes.fromhex(query))
    resp = s.recv(1024)
    print(resp)

    if not(b'telephone' in resp):
        print('no user')
    else:
        print(resp[resp.index(b'telephone')+19:resp.index(b'telephone')+29])

s.close()


