#from ldap3 import Server, Connection, ALL


#server = Server('192.168.0.118', get_info=ALL)
#conn = Connection(server, auto_bind=True)
#print(server.info)

#conn.search('dc=prac,dc=com', '(objectClass=person)')
#print(conn.entries)

import binascii


def BERString(sline):
    line = binascii.hexlify(sline)
    length = binascii.hexlify(len(sline).to_bytes(1, 'big'))
    #length = len(sline).to_bytes(1, 'big')
    tag = '04'
    return tag, length, line


def addHex(v1,v2):
    return hex(int(v1, 16) + int(v2, 16))


def uidName(sline:str):
    return sline[0]+sline[sline.find(" ")+1:len(sline)]

print(BERString(b'L19m2992'))

#040967726f75706e616d65
#0406667269656e64