import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.StringTokenizer;
import org.mariuszgromada.math.mxparser.*;


/* D.S Kapnias u18108467 */
/* L.M Burgess u18015001 */

public class server {
    public static String equation;
    public static void main(String[] args) throws IOException {
    /*************************************************************************/
        /*File f = new File(System.getProperty("user.dir") + "/sample.txt");
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }*/
    /*************************************************************************/


        ServerSocket Server = null;
        try {
            Server = new ServerSocket(5000);
            equation = "";
            while (true) {
                new Client(Server.accept()).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {

        }
    }

        static class Client extends Thread {
            StringTokenizer breaker = null;
            Socket socket;
            BufferedReader  input= null;
            OutputStream output= null;
            String req[];
            //File f = new File(System.getProperty("user.dir") + "/sample.txt");


            public Client(Socket user) {
                socket = user;
                try {
                    input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    output = socket.getOutputStream();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void run() {
                super.run();
                try {
                    String line = null;
                    //while(true) {
                        line = input.readLine();
                        if(line != null) {
                            //System.out.println(line);
                            req = parseRequest(line);
                            if(req[0].equals("GET")) {
                                if(req[1].equals("/")) {
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/+")) {
                                    equation = equation + "+";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/div")) {
                                    equation = equation + "/";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/*")) {
                                    equation = equation + "*";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/-")) {
                                    equation = equation + "-";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/1")) {
                                    equation = equation + "1";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/2")) {
                                    equation = equation + "2";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/3")) {
                                    equation = equation + "3";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/4")) {
                                    equation = equation + "4";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/5")) {
                                    equation = equation + "5";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/6")) {
                                    equation = equation + "6";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/7")) {
                                    equation = equation + "7";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/8")) {
                                    equation = equation + "8";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/9")) {
                                    equation = equation + "9";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/0")) {
                                    equation = equation + "0";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/dot")) {
                                    equation = equation + ".";
                                    printHTML(equation, output);
                                }
                                else if(req[1].equals("/ntr")) {
                                    equation = EvalEquation(equation);
                                    printHTML(equation, output);
                                    if(equation.equals("NaN"))
                                        equation= "";
                                }
                                else if(req[1].equals("/clr")) {
                                    equation = "";
                                    printHTML(equation, output);
                                }
                            } else if(req[0].equals("PUT")) {
                                line = input.readLine();
                                print("PUT\n");
                                while(!line.contains("Content-Length:")) {
                                    line = input.readLine();
                                    while (line == null) {
                                    }
                                    print(line);
                                }
                                int length = Integer.parseInt(line.substring(line.indexOf(":")+1,line.length()).trim());
                                input.readLine();
                                if(length==0)
                                    badHeaders("","");
                                else {
                                    System.out.println("Parse body");
                                    int i = 0;
                                    /*while(((char)input.read())!='=')
                                        i++;
                                    */equation = "";
                                    for (; i < length; i++) {
                                        equation = equation + ((char) input.read());
                                    }
                                    //System.out.println(equation);

                                    String what = req[1];

                                    if(!what.equals("/sample.txt")) {
                                        String status_line = "HTTP/1.1 301 Moved Permanently \r\n";
                                        String Empty = "\r\n";
                                        output.write(status_line.getBytes(StandardCharsets.UTF_8));
                                        output.write(Empty.getBytes(StandardCharsets.UTF_8));

                                    }
                                    else {
                                        File f = new File(System.getProperty("user.dir") + what);
                                        f.delete();
                                        f.createNewFile();
                                        try {
                                            FileWriter myWriter = new FileWriter(System.getProperty("user.dir") + what);
                                            myWriter.write(equation);
                                            myWriter.close();
                                            /* Send response */
                                            String status_line = "HTTP/1.1 200 OK \r\n";
                                            String Empty = "\r\n";
                                            output.write(status_line.getBytes(StandardCharsets.UTF_8));
                                            output.write(Empty.getBytes(StandardCharsets.UTF_8));
                                        } catch (IOException e) {
                                            String status_line = "HTTP/1.1 301 Moved Permanently \r\n";
                                            String Empty = "\r\n";
                                            output.write(status_line.getBytes(StandardCharsets.UTF_8));
                                            output.write(Empty.getBytes(StandardCharsets.UTF_8));
                                        }

                                        /* Send response */
                                        String status_line = "HTTP/1.1 200 OK \r\n";
                                        String Header = "Content-Type: text/html\r\nContent-Length: 0\r\n";
                                        String Empty = "\r\n";
                                        output.write(status_line.getBytes(StandardCharsets.UTF_8));
                                        //output.write(Header.getBytes(StandardCharsets.UTF_8));
                                        output.write(Empty.getBytes(StandardCharsets.UTF_8));
                                    }
                                }
                            } else if(req[0].equals("DELETE")) {
                                String what = req[1];
                                File f = new File(System.getProperty("user.dir") + what);
                                if(f.exists()) {
                                print(what);
                                    equation = "0";
                                    f.delete();
                                    f.createNewFile();
                                    try {
                                        FileWriter myWriter = new FileWriter(System.getProperty("user.dir") + what);
                                        myWriter.write("0");
                                        myWriter.close();
                                        /* Send response */
                                        String status_line = "HTTP/1.1 200 OK \r\n";
                                        String Empty = "\r\n";
                                        output.write(status_line.getBytes(StandardCharsets.UTF_8));
                                        output.write(Empty.getBytes(StandardCharsets.UTF_8));
                                    } catch (IOException e) {
                                        String status_line = "HTTP/1.1 301 Moved Permanently \r\n";
                                        String Empty = "\r\n";
                                        output.write(status_line.getBytes(StandardCharsets.UTF_8));
                                        output.write(Empty.getBytes(StandardCharsets.UTF_8));
                                    }
                                /*******************************************************************/
                                } else {
                                    String status_line = "HTTP/1.1 301 Moved Permanently \r\n";
                                    String Empty = "\r\n";
                                    output.write(status_line.getBytes(StandardCharsets.UTF_8));
                                    output.write(Empty.getBytes(StandardCharsets.UTF_8));
                                }
                            }
                        }
                    //}

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            private void badHeaders(String s, String s1) {
                String status_line = "HTTP/1.1 400 Bad Request \r\n";
                String Header = "Content-Type: text/html\r\nContent-Length: 0\r\n";
                String Empty = "\r\n";
            }

            private String EvalEquation(String equation) {
                /*ScriptEngineManager SEM = new ScriptEngineManager();
                ScriptEngine SE = SEM.getEngineByName("JavaScript");
                String ret = "";
                try {
                    ret = String.valueOf(SE.eval(equation));
                } catch (ScriptException e) {
                    ret = "Error";
                }
                return ret;*/
                Expression e = new Expression(equation);
                return String.valueOf(e.calculate());
            }

            private String[] parseRequest(String line) throws Error {
                print(line);
                String ret[] = new String[3];
                breaker = new StringTokenizer(line);
                for (int i = 0; i < 3; i++) {
                    if(breaker.hasMoreTokens()) {
                        ret[i] = breaker.nextToken();
                        //print(ret[i]);
                    } else {
                        throw new Error("Request faulty");
                    }
                }
                return ret;
            }

        }

        public static void printHTML(String equation, OutputStream output) throws IOException {
            /* gen resp */
            String status_line = "HTTP/1.1 200 OK \r\n";
            String Header = "Content-Type: text/html\r\nContent-Length: ";
            String BodyStart = "\r\n";
            String HTML = "<!DOCTYPE html>\n" +
                    "<html lang=\"en\">\n" +
                    "<head>\n" +
                    "    <meta charset=\"UTF-8\">\n" +
                    "    <title>Calculator</title>\n" +
                    "</head>\n" +
                    "<body>\n" +
                    "    <div>\n" +
                    "        <style>\n" +
                    "            .tg  {border-collapse:collapse;border-spacing:0;}\n" +
                    "            .tg td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;\n" +
                    "                overflow:hidden;padding:10px 5px;word-break:normal;}\n" +
                    "            .tg th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;\n" +
                    "                font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}\n" +
                    "            .tg .tg-2rgp{border-color:#000000;font-family:\"Trebuchet MS\", Helvetica, sans-serif !important;font-size:28px;font-weight:bold;\n" +
                    "                text-align:center;vertical-align:top}\n" +
                    "        </style>\n" +
                    "        <table class=\"tg\">\n" +
                    "            <thead>\n" +
                    "            <tr>\n" +
                    "                <th class=\"tg-0lax\" colspan=\"4\">"+equation+"</th>\n" +
                    "            </tr>\n" +
                    "            </thead>\n" +
                    "            <tbody>\n" +
                    "            <tr>\n" +
                    "                <th class=\"tg-2rgp\"><a href=\"div\">/</a></th>\n" +
                    "                <th class=\"tg-2rgp\"><a href=\"*\">*</a></th>\n" +
                    "                <th class=\"tg-2rgp\"><a href=\"-\">-</a></th>\n" +
                    "                <th class=\"tg-2rgp\"><a href=\"+\">+</a></th>\n" +
                    "            </tr>\n" +
                    "            <tr>\n" +
                    "                <td class=\"tg-2rgp\"><a href=\"7\">7</a></td>\n" +
                    "                <td class=\"tg-2rgp\"><a href=\"8\">8</a></td>\n" +
                    "                <td class=\"tg-2rgp\"><a href=\"9\">9</a></td>\n" +
                    "                <td class=\"tg-2rgp\" rowspan=\"2\"><a href=\"clr\">clr</a></td>\n" +
                    "            </tr>\n" +
                    "            <tr>\n" +
                    "                <td class=\"tg-2rgp\"><a href=\"4\">4</a></td>\n" +
                    "                <td class=\"tg-2rgp\"><a href=\"5\">5</a></td>\n" +
                    "                <td class=\"tg-2rgp\"><a href=\"6\">6</a></td>\n" +
                    "            </tr>\n" +
                    "            <tr>\n" +
                    "                <td class=\"tg-2rgp\"><a href=\"1\">1</a></td>\n" +
                    "                <td class=\"tg-2rgp\"><a href=\"2\">2</a></td>\n" +
                    "                <td class=\"tg-2rgp\"><a href=\"3\">3</a></td>\n" +
                    "                <td class=\"tg-2rgp\" rowspan=\"2\"><a href=\"ntr\">ntr</a><br></td>\n" +
                    "            </tr>\n" +
                    "            <tr>\n" +
                    "                <td class=\"tg-2rgp\" colspan=\"2\"><a href=\"0\">0</a></td>\n" +
                    "                <td class=\"tg-2rgp\"><a href=\"dot\">.</a></td>\n" +
                    "            </tr>\n" +
                    "            </tbody>\n" +
                    "        </table>\n" +
                    "    </div>\n" +
                    "</body>\n" +
                    "</html>";

            Header += String.valueOf(HTML.getBytes(StandardCharsets.UTF_8).length) +"\r\n";
            /* Send http response */
            output.write(status_line.getBytes(StandardCharsets.UTF_8));
            output.write(Header.getBytes(StandardCharsets.UTF_8));
            output.write(BodyStart.getBytes(StandardCharsets.UTF_8));
            output.write(HTML.getBytes(StandardCharsets.UTF_8));
            output.flush();
        }



    public static void print(String line) {
        System.out.println(line);
    }
}
