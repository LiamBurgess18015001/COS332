import time
file = open("index.html", 'r')
item1 = file.read().encode("ASCII")
file.close()

time.sleep(8)

file = open("index.html", 'r')
item2 = file.read().encode("ASCII")
file.close()

if item1 == item2:
    print(True)
else:
    print(False)