import socket
import time
import keyboard

URL = "196.248.39.8"
PORT = 21
USERNAME = "USER liam\r\n"
PASSWORD = "PASS L19m2992\r\n"
RENAME_FROM = "RNFR /home/liam/Upload/"
RENAME_TO = "RNTO /home/liam/Upload/"
CWD = "CWD /home/liam/Upload\r\n"
PASV = "PASV\r\n"
STORE = "STOR /home/liam/Upload/"
NOOP = "NOOP\r\n"
LIST = "LIST /home/liam/Upload\r\n"
QUIT = "QUIT\r\n"
DATAPORT = 0
FILENAME = "index.html"

file = open("index.html", 'r')
FILE_DATA = file.read().encode("ASCII")
file.close()

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((URL, PORT))
print(s.recv(512))

s.send(USERNAME.encode("ASCII"))
print(s.recv(512))

s.send(PASSWORD.encode("ASCII"))
login_line = (s.recv(512)).decode("ASCII")
print(login_line)
login = login_line.find("Login successful")

s.send(CWD.encode("ASCII"))
print(s.recv(512))

#filename = input("rename index ")

##########################################

if True:
    s.send(NOOP.encode("ASCII"))
    resp = s.recv(512).decode("ASCII")
    print(resp)
    if resp.find('200') == -1:
        print("Server Unreachable\r\n")
        quit(-1)
    else:
        print("Server Reached\r\n")
        s.send(PASV.encode("ASCII"))
        findPort = s.recv(512).decode("ASCII")
        print("findport "+findPort)
        dataPort = findPort[40:findPort.index(")")]
        dataPort = int(dataPort[0:dataPort.index(",")]) * 256 + int(dataPort[dataPort.index(",") + 1:len(dataPort)])
        print(dataPort)
        DATAPORT = dataPort
        DATA_STREAM = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        DATA_STREAM.connect((URL, DATAPORT))
        s.send(LIST.encode("ASCII"))
        resp = s.recv(512).decode("ASCII")
        print(resp)
        print(DATA_STREAM.recv(512))
        rename = input("Rename file?\r\n")
        if rename == 't':
            old = input("old file name from list\r\n")
            if old == "":
                quit(-1)
            else:
                renameFrom = RENAME_FROM + old +"\r\n"
                print(renameFrom)
                s.send(renameFrom.encode("ASCII"))
                print(s.recv(512))
                newName = input("new file name\r\n")
                if newName == "":
                    quit(-1)
                else:
                    renameTo = RENAME_TO + newName +"\r\n"
                    s.send(renameTo.encode("ASCII"))
                    print(s.recv(512))
                    DATA_STREAM.close()
        else:
            DATA_STREAM.close()

file = input("file to change")
if file == "":
    print("no file")
    quit(-1)

STORE = STORE + file +"\r\n"
print(STORE)

##########################################

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((URL, PORT))
print(s.recv(512))

s.send(USERNAME.encode("ASCII"))
print(s.recv(512))

s.send(PASSWORD.encode("ASCII"))
login_line = (s.recv(512)).decode("ASCII")
print(login_line)
login = login_line.find("Login successful")

s.send(CWD.encode("ASCII"))
print(s.recv(512))


##########################################
while True:
    print("Compare")
    time.sleep(10)
    file = open("index.html", 'r')
    FILE_COMPARE = file.read().encode("ASCII")
    file.close()

    if FILE_COMPARE != FILE_DATA:
        s.send(NOOP.encode("ASCII"))
        resp = s.recv(512).decode("ASCII")
        print(resp)
        if resp.find('200') == -1:
            print("Server Unreachable")
            break
        else:
            print("Server Reached")

        s.send(PASV.encode("ASCII"))
        findPort = s.recv(512).decode("ASCII")
        print(findPort)
        dataPort = findPort[40:findPort.index(")")]
        dataPort = int(dataPort[0:dataPort.index(",")]) * 256 + int(dataPort[dataPort.index(",")+1:len(dataPort)])
        print(dataPort)
        DATAPORT = dataPort
        DATA_STREAM = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        DATA_STREAM.connect((URL, DATAPORT))
        #print(DATA_STREAM.recv(256))

        print("STORE")
        s.send(STORE.encode("ASCII"))
        print(s.recv(512))

        DATA_STREAM.send(FILE_COMPARE)
        # end transfer
        DATA_STREAM.close()
        print(s.recv(512))
    elif keyboard.read_key() == 'e':
        break
    FILE_DATA = FILE_COMPARE

#######################################################

s.send(QUIT.encode("ASCII"))
print(s.recv(512))
s.close()


