var http = require('http');
var equation = '';
var save = '';
var server = http.createServer(function (req, res) {
    console.log(req.toString());

    if(req.method == 'PUT' && req.url=="/") {
        let data = '';
        req.on("data", (INdata) => {
            data += INdata;
        });
        req.on("end", ()=> {
            let field = data.toString().substring(0,data.toString().indexOf("="));
            if(field == "equation") {
                equation = eval(data.toString().substring(data.toString().indexOf("=")+1,data.toString().length));
                res.writeHead(200);
            } else {
                res.writeHead(204);
            }
        });
        res.end();
    }
    else if(req.method == 'DELETE' && req.url=="/") {
        let data = '';
        req.on("data", (INdata) => {
            data += INdata;
        });
        req.on("end", ()=> {
            let deleter = data.toString().substring(data.toString().indexOf("=")+1,data.toString().length);
            if(deleter == 'equation') {
                equation = '';
                res.writeHead(200);
            } else {
                res.writeHead(204);
            }
            res.end();
        });
    }
    else if(req.method == 'GET' && req.url=="/") {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/+') {
        equation = equation + "+";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/div') {
        equation = equation + "/";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/*') {
        equation = equation + "*";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/-') {
        equation = equation + "-";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/clr') {
        equation = "";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/9') {
        equation = equation + "9";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/8') {
        equation = equation + "8";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/7') {
        equation = equation + "7";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/6') {
        equation = equation + "6";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/5') {
        equation = equation + "5";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/4') {
        equation = equation + "4";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/3') {
        equation = equation + "3";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/2') {
        equation = equation + "2";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/1') {
        equation = equation + "1";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/0') {
        equation = equation + "0";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/dot') {
        equation = equation + ".";
        res.writeHead(200, { 'Content-Type': 'text/html' });
        sendHTML(equation,res);
        res.end();
    }
    else if(req.method == 'GET' && req.url=='/ntr') {
        var answer;
        try {
            answer = eval(equation);
        } catch(error) {
            console.log(error);
            answer = "Error";
        }
        res.writeHead(200, { 'Content-Type': 'text/html' });
        if(answer == undefined)
            answer = "";
        equation = answer.toString();
        sendHTML(answer,res);
        res.end();
    }
});

server.listen(5050);
console.log("Server start 5050");

function sendHTML(equation, response) {
    response.write("<!DOCTYPE html>\n" +
        "<html lang=\"en\">\n" +
        "<head>\n" +
        "    <meta charset=\"UTF-8\">\n" +
        "    <title>Calculator</title>\n" +
        "</head>\n" +
        "<body>\n" +
        "    <div>\n" +
        "        <style>\n" +
        "            .tg  {border-collapse:collapse;border-spacing:0;}\n" +
        "            .tg td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;\n" +
        "                overflow:hidden;padding:10px 5px;word-break:normal;}\n" +
        "            .tg th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;\n" +
        "                font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}\n" +
        "            .tg .tg-2rgp{border-color:#000000;font-family:\"Trebuchet MS\", Helvetica, sans-serif !important;font-size:28px;font-weight:bold;\n" +
        "                text-align:center;vertical-align:top}\n" +
        "        </style>\n" +
        "        <table class=\"tg\">\n" +
        "            <thead>\n" +
        "            <tr>\n" +
        "                <th class=\"tg-0lax\" colspan=\"4\">"+equation+"</th>\n" +
        "            </tr>\n" +
        "            </thead>\n" +
        "            <tbody>\n" +
        "            <tr>\n" +
        "                <th class=\"tg-2rgp\"><a href=\"div\">/</a></th>\n" +
        "                <th class=\"tg-2rgp\"><a href=\"*\">*</a></th>\n" +
        "                <th class=\"tg-2rgp\"><a href=\"-\">-</a></th>\n" +
        "                <th class=\"tg-2rgp\"><a href=\"+\">+</a></th>\n" +
        "            </tr>\n" +
        "            <tr>\n" +
        "                <td class=\"tg-2rgp\"><a href=\"7\">7</a></td>\n" +
        "                <td class=\"tg-2rgp\"><a href=\"8\">8</a></td>\n" +
        "                <td class=\"tg-2rgp\"><a href=\"9\">9</a></td>\n" +
        "                <td class=\"tg-2rgp\" rowspan=\"2\"><a href=\"clr\">clr</a></td>\n" +
        "            </tr>\n" +
        "            <tr>\n" +
        "                <td class=\"tg-2rgp\"><a href=\"4\">4</a></td>\n" +
        "                <td class=\"tg-2rgp\"><a href=\"5\">5</a></td>\n" +
        "                <td class=\"tg-2rgp\"><a href=\"6\">6</a></td>\n" +
        "            </tr>\n" +
        "            <tr>\n" +
        "                <td class=\"tg-2rgp\"><a href=\"1\">1</a></td>\n" +
        "                <td class=\"tg-2rgp\"><a href=\"2\">2</a></td>\n" +
        "                <td class=\"tg-2rgp\"><a href=\"3\">3</a></td>\n" +
        "                <td class=\"tg-2rgp\" rowspan=\"2\"><a href=\"ntr\">ntr</a><br></td>\n" +
        "            </tr>\n" +
        "            <tr>\n" +
        "                <td class=\"tg-2rgp\" colspan=\"2\"><a href=\"0\">0</a></td>\n" +
        "                <td class=\"tg-2rgp\"><a href=\"dot\">.</a></td>\n" +
        "            </tr>\n" +
        "            </tbody>\n" +
        "        </table>\n" +
        "    </div>\n" +
        "</body>\n" +
        "</html>");
    return;
}