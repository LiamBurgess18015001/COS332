#!/usr/bin/env perl
open (writer, ">backend_file.txt") or die "$! error trying to overwrite";
print writer 2;
print "Content-type: text/html;\n\n";
print "<a href='LANDING.pl'>GO TO LANDING</a><br>\n\n";
print "<h1> Timezone changed to Ghana on landing </h1>"
#print "<a href='RSA.pl'>GO TO RSA</a><br>\n\n";

#$epoch = time();
#$epoch = $epoch - 2 * 60 * 60;  

#$datestring = localtime($epoch);
#print "The date and time in Ghana: $datestring\n";
