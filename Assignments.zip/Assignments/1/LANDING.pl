#!/usr/bin/env perl
print "Content-type: text/html;\n\n";
my $filename = 'backend_file.txt';
open(my $fh, '<:encoding(UTF-8)', $filename)
  or die "Could not open file '$filename' $!";
  print "<a href='GHANA.pl'>GO TO GHANA</a><br>\n\n";
  print "<a href='RSA.pl'>GO TO RSA</a><br>\n\n";
 
my $row = <$fh>;

if($row=='0') {
	$epoch = time();
	$datestring = localtime($epoch);
	print "The date and time in - the backend file - South Africa(Pretoria): $datestring\n";
	
} else {
	$epoch = time();
	$epoch = $epoch - 2 * 60 * 60;  
	$datestring = localtime($epoch);
	print "The date and time in - the backend file - Ghana: $datestring\n";
}

	print "<br>";
	$epoch = time();
	$datestring = localtime($epoch);
	print "The date and time locally: $datestring\n";
