#!/usr/bin/env perl
open (writer, ">backend_file.txt") or die "$! error trying to overwrite";
print writer 0;
print "Content-type: text/html;\n\n";
print "<a href='LANDING.pl'>GO TO LANDING</a><br>\n\n";

print "<h1> Timezone changed to RSA on landing </h1>"

#print "<a href='GHANA.pl'>GO TO GHANA</a><br>\n\n";
#$epoch = time();

#$datestring = localtime($epoch);
#print "The date and time in South Africa(Pretoria): $datestring\n";
