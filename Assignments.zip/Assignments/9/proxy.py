import socket
import re
import time

######################
def findPS(sline: str):
    return sline.upper.find('PS')


# find ps
# find last linked command to the right
# delete from command to ps

def stripPS(sline: str):
    compound = ["&&", "||"]
    isolated = ["&", ";"]
    arr = sline.split()
    if ('ps' in arr) and (len(arr)==1):
        return ""
    while 'ps' in arr:
        i = arr.index("ps")
        if i == len(arr) - 1:
            arr.pop(len(arr) - 1)
            if arr[len(arr)-1] in isolated:
                arr.pop(len(arr) - 1)
            break
        if i > 0:
            if arr[i - 1] in compound:
                arr.pop(i - 1)
                i = arr.index("ps")
            if arr[i - 1] in isolated[0]:

                while arr[i + 1].find("-") != -1:
                    arr.pop(i + 1)
                    if i == (len(arr)-1):
                        break
                arr.pop(i - 1)
                arr.pop(i - 1)
                continue
        if i + 1 < len(arr):
            j = i + 1
            while True:
                if j >= len(arr):
                    arr = arr[0:i - 1]
                    break
                if arr[j].find("-") != -1 and arr[j - 1].find("ps") != -1:
                    arr.pop(j)
                    continue
                if arr[j] in compound:
                    j = j + 2
                else:
                    if j != (len(arr) - 1):
                        if arr[j - 1] in compound:
                            j = j - 1
                    for k in range(j, arr.index('ps'), -1):
                        arr.pop(k)
                    arr.pop(i)
                    if i < len(arr):
                        if arr[i] == arr[i-1]:
                            arr.pop(i)
                    break
        elif i + 1 == len(arr) - 1:
            arr.pop(len(arr) - 1)
            arr.pop(len(arr) - 1)
    if len(arr) > 0:
        if arr[len(arr)-1] in compound:
            arr = arr[0:len(arr)-1]
    return " ".join(arr)
######################
def reverseResponse(sline):
    sRet = ""
    while len(sline) > 0:
        if sline[0:2] == 'ff':
            sRet += "ff"
            sline = sline[2:len(sline)]
            # DO
            if sline[0:2] == 'fd':
                sRet += 'fc'
                sline = sline[2:len(sline)]
            # WILL
            elif sline[0:2] == 'fb':
                sRet += 'fe'
                sline = sline[2:len(sline)]
            sRet += sline[0:2]
            if len(sline) <= 2:
                sline = ""
            else:
                sline = sline[2:len(sline)]
    return sRet

######################
def terminalRead(server):
    sline = ""
    while sline.find("\r\n") < 0:
        try:
            sline += server.recv(1).decode("UTF-8")
        except:
            continue
    return stripPS(sline)
######################
IAC = bytes.fromhex('ff')
DONT = bytes.fromhex('fe')
DO = bytes.fromhex('fd')
WONT = bytes.fromhex('fc')
WILL = bytes.fromhex('fb')
ECHO = bytes.fromhex('01')
SUPPRESS = bytes.fromhex('2d')
LOGOUT = bytes.fromhex('18')
######################

def connect(hostname, port, username, password, command):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((hostname, int(port)))
        sline = s.recv(256)
        while sline.find(b"Ubuntu") < 0:
            sline = sline.hex()
            sRet = reverseResponse(sline)
            toSend = bytes.fromhex(sRet)
            #print(toSend)
            s.send(toSend)
            sline = s.recv(256)
            print(sline)

        print(s.recv(4096).decode("UTF-8"))
        s.send(username.encode("UTF-8") + b'\r\n')
        time.sleep(0.5)
        print(s.recv(4096).decode("UTF-8"))
        s.send(password.encode("UTF-8") + b'\r\n')
        time.sleep(0.5)
        print(s.recv(4096).decode("UTF-8"))

        send = command + "\r\n"
        s.send(send.encode("UTF-8"))
        time.sleep(0.5)
        retString = s.recv(8192).decode("UTF-8").replace(send, "")

        send = "exit\r\n"
        s.send(send.encode("UTF-8"))

        return retString

if __name__ == '__main__':
    HOST = 'localhost'
    PORT = 5000
    hostname = '192.168.56.102'
    port = '23'
    username = 'liam'
    password = 'L19m2992'

    serv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serv.bind((HOST, PORT))
    serv.listen(1)

    conn, addr = serv.accept()
    data = ""
while 1:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        conn.send(b"Hostname:\r\n")
        hostname = terminalRead(conn)
        conn.send(b"Port:\r\n")
        port = terminalRead(conn).replace('\r\n', "")
        s.connect((hostname, int(port)))
        sline = ""
        sline = s.recv(256)
        while sline.find(b"Ubuntu") < 0:
            sline = sline.hex()
            sRet = reverseResponse(sline)
            toSend = bytes.fromhex(sRet)
            #print(toSend)
            s.send(toSend)
            sline = s.recv(256)
            print(sline)

        print(s.recv(4096).decode("UTF-8"))
        conn.send(b"Username:\r\n")
        username = terminalRead(conn)
        s.send(username.encode("UTF-8") + b'\r\n')
        time.sleep(0.5)
        sfind = s.recv(4096)
        print(sfind.decode("UTF-8"))
        conn.send(b"Password:\r\n")
        password = terminalRead(conn)
        s.send(password.encode("UTF-8") + b'\r\n')
        time.sleep(0.5)
        print(s.recv(2048).decode("UTF-8"))

        while 1:
            send = terminalRead(conn)
            if send.find(":quit") != -1:
                break
            s.send(send.encode("UTF-8") + b"\r\n")
            time.sleep(1)
            receive = s.recv(8192).replace(send.encode('UTF-8'), b"")
            conn.send(receive)

