import socket
import time
######################
IAC = bytes.fromhex('ff')
DONT = bytes.fromhex('fe')
DO = bytes.fromhex('fd')
WONT = bytes.fromhex('fc')
WILL = bytes.fromhex('fb')
ECHO = bytes.fromhex('01')
SUPPRESS = bytes.fromhex('2d')
######################

HOST = 'localhost'
PORT = 8787
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen(1)

conn, addr = s.accept()

data = b""
conn.send(b"Welcome to fake Ubuntu")
conn.send(b"Welcome to fake Ubuntu")
while 1:
    time.sleep(0.5)
    data = conn.recv(64)
    conn.send(b"term>"+data)

conn.close()