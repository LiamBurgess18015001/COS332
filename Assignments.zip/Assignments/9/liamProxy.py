import socket
import time
######################
def reverseResponse(sline):
    sRet = ""
    while len(sline) > 0:
        if sline[0:2] == 'ff':
            sRet += "ff"
            sline = sline[2:len(sline)]
            # DO
            if sline[0:2] == 'fd':
                sRet += 'fc'
                sline = sline[2:len(sline)]
            # WILL
            elif sline[0:2] == 'fb':
                sRet += 'fe'
                sline = sline[2:len(sline)]
            sRet += sline[0:2]
            if len(sline) <= 2:
                sline = ""
            else:
                sline = sline[2:len(sline)]
    return sRet

######################
IAC = bytes.fromhex('ff')
DONT = bytes.fromhex('fe')
DO = bytes.fromhex('fd')
WONT = bytes.fromhex('fc')
WILL = bytes.fromhex('fb')
ECHO = bytes.fromhex('01')
SUPPRESS = bytes.fromhex('2d')
LOGOUT = bytes.fromhex('18')
######################

HOST = "192.168.56.102"
PORT = 23

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    sline = ""
    sline = s.recv(256)
    while sline.find(b"Ubuntu") < 0:
        sline = sline.hex()
        sRet = reverseResponse(sline)
        toSend = bytes.fromhex(sRet)
        #print(toSend)
        s.send(toSend)
        sline = s.recv(256)
        print(sline)

    print(s.recv(4096).decode("UTF-8"))
    while 1:
        send = input("") + "\r\n"
        if send.find(":quit") != -1:
            break
        s.send(send.encode("UTF-8"))
        time.sleep(0.5)
        print(s.recv(8192).decode("UTF-8").replace(send, ""))

        if data.find(b':quit\r\n') != -1:
            break
        elif data.find(b':on\r\n') != -1:
            conn.send(IAC)
            conn.send(WONT)
            conn.send(ECHO)
            print(conn.recv(1))
            print(conn.recv(1))
            print(conn.recv(1))
            data = b""
        elif data.find(b":off\r\n") != -1:
            conn.send(IAC)
            conn.send(WILL)
            conn.send(ECHO)
            print(conn.recv(1))
            print(conn.recv(1))
            print(conn.recv(1))
            data = b""
        elif data.find(b'\r\n') != -1:
            data = b''
        else:
            print(data.hex())




