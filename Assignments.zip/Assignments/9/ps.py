def findPS(sline: str):
    return sline.upper.find('PS')


# find ps
# find last linked command to the right
# delete from command to ps

def stripPS(sline: str):
    compound = ["&&", "||"]
    isolated = ["&", ";"]
    arr = sline.split()
    if ('ps' in arr) and (len(arr)==1):
        return ""
    while 'ps' in arr:
        i = arr.index("ps")
        if i == len(arr) - 1:
            arr.pop(len(arr) - 1)
            if arr[len(arr)-1] in isolated:
                arr.pop(len(arr) - 1)
            break
        if i > 0:
            if arr[i - 1] in compound:
                arr.pop(i - 1)
                i = arr.index("ps")
            if arr[i - 1] in isolated[0]:

                while arr[i + 1].find("-") != -1:
                    arr.pop(i + 1)
                    if i == (len(arr)-1):
                        break
                arr.pop(i - 1)
                arr.pop(i - 1)
                continue
        if i + 1 < len(arr):
            j = i + 1
            while True:
                if j >= len(arr):
                    arr = arr[0:i - 1]
                    break
                if arr[j].find("-") != -1 and arr[j - 1].find("ps") != -1:
                    arr.pop(j)
                    continue
                if arr[j] in compound:
                    j = j + 2
                else:
                    if j != (len(arr) - 1):
                        if arr[j - 1] in compound:
                            j = j - 1
                    for k in range(j, arr.index('ps'), -1):
                        arr.pop(k)
                    arr.pop(i)
                    if i < len(arr):
                        if arr[i] == arr[i-1]:
                            arr.pop(i)
                    break
        elif i + 1 == len(arr) - 1:
            arr.pop(len(arr) - 1)
            arr.pop(len(arr) - 1)
    if arr[len(arr)-1] in compound:
        arr = arr[0:len(arr)-1]
    return " ".join(arr)


print(stripPS("cd ; ps && cd || fs >> ls && ps & cd ; ps ;"))
print(stripPS("ls & ps & cd /etc"))
print(stripPS("ls -alh && ps -aux && cat text.txt"))
print(stripPS("ls & ps & cat test.txt"))
print(stripPS("ls && ps || cat test.txt"))
print(stripPS("ls & ps -aux"))
print(stripPS("ls -a ; ps && echo hello ; echo bye"))
#print(stripPS("cd & ps"))
print(stripPS("ls  -a  &&  ps"))